drop user 'tianmh'@'%';
flush privileges;
create user 'tianmh'@'%' IDENTIFIED by 'root';
grant all PRIVILEGES on *.* to 'tianmh'@'%';