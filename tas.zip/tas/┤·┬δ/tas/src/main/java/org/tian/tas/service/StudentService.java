package org.tian.tas.service;

import org.tian.tas.entity.Student;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface StudentService extends IService<Student> {

}
