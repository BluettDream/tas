package org.tian.tas.mapper;

import org.tian.tas.entity.Teacher;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity org.tian.tas.entity.Teacher
 */
public interface TeacherMapper extends BaseMapper<Teacher> {

}




