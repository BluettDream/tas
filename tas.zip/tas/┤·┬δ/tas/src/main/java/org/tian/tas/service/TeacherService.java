package org.tian.tas.service;

import org.tian.tas.entity.Teacher;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 *
 */
public interface TeacherService extends IService<Teacher> {

}
