package org.tian.tas.mapper;

import org.tian.tas.entity.Student;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @Entity org.tian.tas.entity.Student
 */
public interface StudentMapper extends BaseMapper<Student> {

}




